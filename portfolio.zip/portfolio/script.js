// script.js

document.addEventListener("DOMContentLoaded", function() {
    // Social media icons
    const socialIconsContainer = document.getElementById("socialIcons");
    const socialMediaIcons = ["7.jpg", "2.jpg", "4.jpg", "5.jpg", "6.jpg"];

    socialMediaIcons.forEach(iconSrc => {
        const icon = document.createElement("img");
        icon.src = iconSrc;
        icon.alt = "Social Media Icon";
        socialIconsContainer.appendChild(icon);
    });

    // Profile picture
    const profilePictureContainer = document.getElementById("profilePicture");
    const profilePictureSrc = "1.jpg"; // Replace with your image path
    const profilePicture = document.createElement("img");
    profilePicture.src = profilePictureSrc;
    profilePicture.alt = "Profile Picture";
    profilePictureContainer.appendChild(profilePicture);
});


// Select the body element
const body = document.body;

// Set the background color
body.style.backgroundColor = "#000000"; // Replace with your desired color

// Optionally, you can also set the text color for better contrast
body.style.color = "#ffffff"; // Replace with your desired text color


document.addEventListener("DOMContentLoaded", function() {
    // Your JavaScript code here
});
